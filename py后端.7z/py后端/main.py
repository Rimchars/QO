import socket
import json
import threading
import datetime
import pymysql

clients = {}


def dbconnect():
    url = 'localhost'
    username = 'root'
    password = '123456'
    database = 'qo、'
    return pymysql.connect(host=url, user=username, password=password, db=database)


def send_message(id1, message, id2):
    db = dbconnect()
    cursor = db.cursor()
    cursor.execute("SELECT status FROM status WHERE id = %s", (id2,))
    row = cursor.fetchone()
    now = datetime.datetime.now()
    if row is not None:
        status = row[0]
        if status == '在线':
            client = clients.get(id2)
            if client is not None:
                cursor.execute("INSERT INTO msg(mid, seid, revid, messageinfo,time) VALUES(%s, %s, %s, %s,%s)",
                               ('send', id1, id2, message, now))
                # Create a dictionary with the data
                data = {"type": "send", "id1": id1, "message": message, "id2": id2, "time": str(now)}
                # Convert the dictionary to a JSON string
                json_data = json.dumps(data)
                T = threading.Thread(target=client.send, args=(json_data.encode(),))
                T.start()
                T.join()
                print("Message sent.\n")
            else:
                print("No such client.")
                cursor.execute("INSERT INTO msg(mid, seid, revid, messageinfo,time) VALUES(%s, %s, %s, %s,%s)",
                               ('send', id1, id2, message, now))
        else:
            print("Client is offline.")
            cursor.execute("INSERT INTO msg(mid, seid, revid, messageinfo,time) VALUES(%s, %s, %s, %s,%s)",
                           ('send', id1, id2, message, now))
    else:
        print("No result found.")
    db.commit()
    db.close()  # Move this to the end of the function


def serch(id, client_socket):
    db = dbconnect()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id = %s or name =%s", (id, id))
    rows = cursor.fetchall()
    if rows:
        for row in rows:
            id1, pwd, name, mail = row
            print(id1, name)
            client_socket.send(json.dumps({"type": "serch", "id": id1, "name": name}).encode())


def add_friend(id1, id2):
    # Send a friend request message
    db = dbconnect()
    cursor = db.cursor()
    cursor.execute("SELECT name FROM users WHERE id = %s", (id1,))
    message = {
        "type": "contacts",
        "name": cursor.fetchone()[0],
        "id": id1,
        "ship": "等待"
    }
    client = clients.get(id2)
    if client is not None:
        # Convert the dictionary to a JSON string
        json_data = json.dumps(message)
        T = threading.Thread(target=client.send, args=(json_data.encode(),))
        T.start()
        T.join()
    # Check if the friendship already exists
    cursor.execute("SELECT * FROM ships WHERE (id1 = %s AND id2 = %s) OR (id1 = %s AND id2 = %s)", (id1, id2, id2, id1))
    if cursor.fetchone() is None:
        cursor.execute("INSERT INTO ships(id1, id2,ship) VALUES(%s, %s,%s)", (id1, id2, '等待'))
        db.commit()
        print("Friend request sent.")
    else:
        print("Friendship or request already exists.")
    cursor.close()
    return message


def accept_friend(id1, id2):
    # Add the new friend to the database
    db = dbconnect()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM ships WHERE (id1 = %s AND id2 = %s) OR (id1 = %s AND id2 = %s)", (id1, id2, id2, id1))
    row = cursor.fetchone()
    response = 'false'  # Default response
    if row is not None:
        if "等待" in row:
            cursor.execute("UPDATE ships SET ship=%s WHERE (id1 = %s AND id2 = %s) OR (id1 = %s AND id2 = %s)",
                           ('好友', id1, id2, id2, id1))
            db.commit()
            ## Send a message to the client to confirm the friendship
            client = clients.get(id2)
            if client is not None:
                # Create a dictionary with the data
                name = cursor.execute("SELECT name FROM users WHERE id = %s", (id1,))
                data = {"type": "contacts", "name": name, "id1": id1, "ship": "好友"}
                # Convert the dictionary to a JSON string
                json_data = json.dumps(data)
                T = threading.Thread(target=client.send, args=(json_data.encode(),))
                T.start()
                T.join()
            if cursor.rowcount == 1:
                print("Friend added.")
                response = 'true'
            else:
                print("Failed to add friend.")
    db.close()
    return response


def delete_friend(id1, id2):
    # Delete the friend from the database
    db = dbconnect()
    cursor = db.cursor()
    cursor.execute("DELETE FROM ships WHERE (id1 = %s AND id2 = %s) OR (id1 = %s AND id2 = %s)", (id1, id2, id2, id1))
    db.commit()
    if cursor.rowcount >= 1:
        print("Friend deleted.")
        response = 'true'
    else:
        print("Failed to delete friend.")
        response = 'false'
    db.close()
    return response


def logininfo(msg, client_socket):
    id, pwd, ip = msg.split(" ")
    db = dbconnect()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id = %s", (id,))
    row = cursor.fetchone()
    clients[client_socket] = id
    if row is not None:
        id1, pwd1, name, mail = row
        if pwd == pwd1:
            cursor.execute("INSERT INTO status(id, ip) VALUES(%s, %s) ON DUPLICATE KEY UPDATE ip = %s, status=%s",
                           (id, ip, ip, '在线'))
            cursor.execute("UPDATE status SET ip = %s, status=%s WHERE id = %s", (ip, '在线', id))

            db.commit()
            client_socket.send(json.dumps({"type": "login", "status": "true"}).encode())
            clients[id] = client_socket
            return json.dumps({"type": "login", "status": "true"})
        else:
            print("Login failed.")
            return json.dumps({"type": "login", "status": "false"})
    else:
        print("No result found.")
        return json.dumps({"type": "login", "status": "false"})
    db.close()


def logoutinfo(msg):
    id, ip = msg.split(" ")
    db = dbconnect()
    cursor = db.cursor()
    cursor.execute("UPDATE status SET status=%s WHERE id = %s", ('离线', id))
    db.commit()
    print("Logout success.")
    db.close()


def registerinfo(msg, client):
    result = 'false'  # Set a default value for result
    id, pwd, name, mail, ip = msg.split(" ")
    db = dbconnect()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM status WHERE id = %s", (id,))
    if cursor.fetchone() is not None:
        result = 'false'
    else:
        sql1 = "INSERT INTO users(id, pwd, name, mail) VALUES (%s, %s, %s, %s)"
        sql2 = "INSERT INTO status(id, ip) VALUES (%s, %s)"
        cursor.execute(sql1, (id, pwd, name, mail))
        cursor.execute(sql2, (id, ip))
        db.commit()
        if cursor.rowcount == 1:
            print("Register success.")
            result = 'true'
        else:
            print("Register failed.")
    db.close()
    client.send(result.encode())


def get_contacts(id, client_socket):
    db = dbconnect()
    cursor = db.cursor()
    cursor.execute("""
        SELECT id1, id2, ship
        FROM ships
        WHERE id1 = %s OR id2 = %s
    """, (id, id))
    rows = cursor.fetchall()
    if rows:
        for row in rows:
            id1, id2, ship = row
            id= int(id)
            id1 = int(id1)
            id2 = int(id2)
            nameid=id1
            if id1 == id:
                nameid = id2
            print("Nameid: ", nameid)
            contacts = {"type": "contacts", "id1": id1, "id2": id2, "ship": ship, "name": getname(nameid)}
            print("Contacts: ", contacts)
            client_socket.send(json.dumps(contacts).encode())
    db.close()

def getname(id):
    db = dbconnect()
    cursor = db.cursor()
    cursor.execute("SELECT name FROM users WHERE id = %s", (id,))
    row = cursor.fetchone()
    if row is not None:
        name = row[0]
        return name
    else:
        return None


def get_message(id, client_socket):
    db = dbconnect()
    cursor = db.cursor()

    # Get the date of three days ago
    three_days_ago = datetime.datetime.now() - datetime.timedelta(days=3)
    cursor.execute("""
        SELECT mid, seid, revid, messageinfo, time 
        FROM msg 
        WHERE (revid = %s OR seid = %s) AND time > %s
    """, (id, id, three_days_ago))

    rows = cursor.fetchall()
    if rows:
        for row in rows:
            mid, id1, id2, message, time = row
            client_socket.send(
                json.dumps({"type": mid, "id1": id1, "message": message, "id2": id2, "time": str(time)}).encode())


def handle_client(client_socket):
    while True:
        try:
            data = client_socket.recv(1024).decode()
            if not data:
                db = dbconnect()
                cursor = db.cursor()
                id = clients.get(client_socket)
                if id is not None:
                    cursor.execute("UPDATE status SET status=%s WHERE id = %s", ('离线', id))
                    db.commit()
                print("Connection to client has been reset.")
                break
        except ConnectionResetError:
            db = dbconnect()
            cursor = db.cursor()
            id = clients.get(client_socket)
            if id is not None:
                cursor.execute("UPDATE status SET status=%s WHERE id = %s", ('离线', id))
                db.commit()
            print("Connection to client has been reset.")
            break
        cmd, msg = (data.split(":", 1) + [None])[:2]
        print("Received: ", cmd, msg)
        if cmd == "login":
            logininfo(msg, client_socket)
        elif cmd == "register":
            registerinfo(msg, client_socket)
        elif cmd == "send":
            id1, message, id2 = msg.split(" ")
            send_message(id1, message, id2)
        elif cmd == "add":
            id1, id2 = msg.split(" ")
            add_friend(id1, id2)
        elif cmd == "accept":
            id1, id2 = msg.split(" ")
            accept_friend(id1, id2)
        elif cmd == "serch":
            results = serch(msg, client_socket)
        elif cmd == "getcontacts":
            get_contacts(msg, client_socket)
        elif cmd == "getmessage":
            get_message(msg, client_socket)


def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('0.0.0.0', 8080))
    server.listen(5)
    while True:
        client_sock, address = server.accept()
        print(f"Accepted connection from {address[0]}:{address[1]}")
        client_handler = threading.Thread(target=handle_client, args=(client_sock,))
        client_handler.start()


if __name__ == "__main__":
    start_server()
